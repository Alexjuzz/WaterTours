package di.service.telephone;

public class TelephoneService {
}
