package di.service.emailsevice.service;

public class SmsService {
}
