package di.enums;

public enum TicketStatus {
    ACTIVE,
    USED,
    EXPIRED
}
