package di.enums;

public enum TripType {
    REGULAR,
    PRIVATE
}
