package di.controller.telephone;

public interface iTelephone {


}
