package di.controller.telephone;

public class TelephoneController implements iTelephone{
}
