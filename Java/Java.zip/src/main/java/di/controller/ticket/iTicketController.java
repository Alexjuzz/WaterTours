package di.controller.ticket;

import org.springframework.web.bind.annotation.RestController;

//TODO ПОДУМАТЬ О КОНТРОЛЛЕРЕ
public interface iTicketController {


}
