package di.model.entity.trips;



public class PrivateTrip {

    public String getDescription() {
        return null;
    }



}